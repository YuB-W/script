-- Created by TutorialMan and YuB-X
-- Discord: TutorialMan#6809

-- Thanks for using Haven Executor (V1.3)

-- V1.3 Features
-- Kill Roblox
-- Save/Open Files